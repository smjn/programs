
void f(){
	int a,b,c;
	a=10;
	b=10;
	c=10;
	a=c;
	a=78;
	b=56;
}

