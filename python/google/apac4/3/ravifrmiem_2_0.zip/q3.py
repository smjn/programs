#! /usr/bin/python
from netaddr import *
t=input()
for j in xrange(t):
    N=input()
    ranges = [IPNetwork(raw_input()) for i in range(N)]
    #print (na.cidr_merge(ranges))
    print "Case #%d:" % (j+1)
    print ('\n'.join(map(lambda x: str(x.cidr), cidr_merge(ranges))))

