#include <stdio.h>

int main ()
{
	int a,b,c,d,h;
	scanf("%d",&h);
	if(h!=0)
	{
		while(a<50)
		{
			if(b<c)
				d=100;
			else
				d=50;
		}
	}
	else
	{
		while(a<50)
		{
			if(b>=c)
				d=200;
			else
				d=150;
		}
	}	

	return 0;
}

