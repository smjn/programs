#include <stdio.h>

int main ()
{
	int a,b,c,d,h,i,j;
	scanf("%d",&h);
	while(h--)
	{
		if(h!=0)
		{
			while(a<50)
			{
				if(b<c)
					d=100;
				else
					d=50;
			}
		}
		else
		{
			for(i=0;i<d;i++)
			{
				j=j+i;
			}
		}	
	}
	return 0;
}

