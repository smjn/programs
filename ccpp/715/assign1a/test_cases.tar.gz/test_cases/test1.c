#include <stdio.h>

int main ()
{
	int a,b,c,d;
	while(a<50)
	{
		if(b<c)
			d=100;
		else
			d=50;
	}
	return 0;
}

